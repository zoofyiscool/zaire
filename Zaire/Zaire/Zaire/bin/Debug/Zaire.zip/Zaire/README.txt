THIS IS A VIRUS.. PLEASE ONLY RUN ON A VIRTUAL MACHINE.

Steps to test:

1) Firstly for this virus to work you need to turn off Windows Defender and any other anti - virus.
2) MAKE SURE THE "Zaire" FOLDER IS ON THE DESKTOP AND IS NAMED "Zaire"
3) Make sure all the files are together.
4) Finally right click the "Zaire" executable and Run as Administrator.